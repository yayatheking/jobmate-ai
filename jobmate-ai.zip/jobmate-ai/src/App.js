import React, { useState } from "react";
import axios from "axios";

export default function App() {
  const [resume, setResume] = useState(null);
  const [parsedData, setParsedData] = useState(null);
  const [jobs] = useState([
    { id: 1, title: "Software Engineer", company: "TechCorp" },
    { id: 2, title: "Product Manager", company: "InnoWorks" },
    { id: 3, title: "UX Designer", company: "DesignHub" },
  ]);

  const pickResume = (e) => setResume(e.target.files[0]);

  const uploadResume = async () => {
    if (!resume) return alert("Select a resume first!");
    const formData = new FormData();
    formData.append("resume", resume);
    try {
      const res = await axios.post(
        "https://ai-job-backend.example.com/parse-resume",
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setParsedData(res.data);
    } catch {
      alert("Error parsing resume");
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>JobMate AI</h1>
      <input type="file" accept=".pdf" onChange={pickResume} />
      <button onClick={uploadResume}>Upload & Parse Resume</button>

      {parsedData && (
        <pre style={{ background: "#eee", padding: 10, marginTop: 20 }}>
          {JSON.stringify(parsedData, null, 2)}
        </pre>
      )}

      <h2>Job Listings</h2>
      <ul>
        {jobs.map((job) => (
          <li key={job.id}>
            {job.title} - {job.company}{" "}
            <button onClick={() => alert(`Applied to ${job.title}`)}>Apply</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
